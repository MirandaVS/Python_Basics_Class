# Text to print
print("Hello, what the fucky world!");
print("AI AI QUE LEGAL");
print("AI AI TA SENSACIONAL");

# Variável
meu_nome = "João Victor"
minha_idade = "19"
minha_altura = "1.66"

