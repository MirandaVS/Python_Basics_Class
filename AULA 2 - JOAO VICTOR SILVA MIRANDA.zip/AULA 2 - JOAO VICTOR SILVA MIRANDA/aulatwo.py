# print = imprimir/exibir
print("Hi, good morning! Give your personal information, please.")

# TIPOS DE VARIÁVEIS
# str = string (texto)
# int = inteiro (números)
# bool = boolean (True and False)

# variáveis = valores
nome_usuario = "João Miranda"
idade_usuario = 19
altura_usuario = 1.66
maior_de_idade = True

print("Hi! My name is", nome_usuario, "I'm", idade_usuario, "years old, my height is", altura_usuario)
print("Maior de idade?", maior_de_idade)


